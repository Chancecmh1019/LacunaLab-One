# LLS-One — recovery / changes note

The uploaded ZIP was truncated: it contains local ZIP entries but no central directory, and `services/renderEngine.ts` is cut off before the end. Files that occur later in the original archive (including imported `types` / `utils` sources) are therefore not recoverable from this upload.

Changes applied to all recoverable files:

- Renamed all recoverable product/package references to `LLS-One` / `lls-one`.
- CD-Booklet: cover + album + title + artist are treated as one vertically centered left-side composition.
- CD-Booklet: long active lyrics are no longer truncated with `...`; the renderer auto-fits font size and wraps the complete active original + translation.
- CD-Booklet: lyric stack is centered around the configured lyric Y anchor and clamped to safe top/bottom bounds.
- CD-Booklet: contextual previous/next translations are reduced only when necessary to preserve the complete active line.
- CD-Booklet: added restrained ambient motion (blurred cover light, drifting guide line, gentle group/lyric float).
- Solid-vintage paper grain now reuses the pre-rendered noise texture instead of drawing 5000 random dots per frame.

Important: because the uploaded archive is incomplete, this recovered folder is not guaranteed to build until the missing original files are restored. Apply `components/LyricVideoEditor.tsx` and the branding changes to the complete repository, or re-upload a complete ZIP for a full build-verified package.
